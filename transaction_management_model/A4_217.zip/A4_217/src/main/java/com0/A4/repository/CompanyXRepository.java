package com0.A4.repository;

import com0.A4.model.CompanyX;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;


public interface CompanyXRepository extends MongoRepository<CompanyX, String> {
    @Override
    Optional<CompanyX> findById(String i);
}
