package com0.A4.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "CompanyZ")
public class CompanyZ {
    @Id
    private String id;
    private String Client217;
    private String User217;
    private List<CompanyX> XParts217;
    private List<CompanyY> YParts217;

    private List<CompanyX> XPOs217;
    private List<CompanyY> YPO217;
    private List<CompanyY> YPOLines217;
    private List<CompanyX> XPOLines217;

    public CompanyZ(String id, String client217, String user217, List<CompanyX> XParts217, List<CompanyY> YParts217, List<CompanyX> XPOs217, List<CompanyY> YPO217, List<CompanyY> YPOLines217, List<CompanyX> XPOLines217) {
        this.id = id;
        Client217 = client217;
        User217 = user217;
        this.XParts217 = XParts217;
        this.YParts217 = YParts217;
        this.XPOs217 = XPOs217;
        this.YPO217 = YPO217;
        this.YPOLines217 = YPOLines217;
        this.XPOLines217 = XPOLines217;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient217() {
        return Client217;
    }

    public void setClient217(String client217) {
        Client217 = client217;
    }

    public String getUser217() {
        return User217;
    }

    public void setUser217(String user217) {
        User217 = user217;
    }

    public List<CompanyX> getXParts217() {
        return XParts217;
    }

    public void setXParts217(List<CompanyX> XParts217) {
        this.XParts217 = XParts217;
    }

    public List<CompanyY> getYParts217() {
        return YParts217;
    }

    public void setYParts217(List<CompanyY> YParts217) {
        this.YParts217 = YParts217;
    }

    public List<CompanyX> getXPOs217() {
        return XPOs217;
    }

    public void setXPOs217(List<CompanyX> XPOs217) {
        this.XPOs217 = XPOs217;
    }

    public List<CompanyY> getYPO217() {
        return YPO217;
    }

    public void setYPO217(List<CompanyY> YPO217) {
        this.YPO217 = YPO217;
    }

    public List<CompanyY> getYPOLines217() {
        return YPOLines217;
    }

    public void setYPOLines217(List<CompanyY> YPOLines217) {
        this.YPOLines217 = YPOLines217;
    }

    public List<CompanyX> getXPOLines217() {
        return XPOLines217;
    }

    public void setXPOLines217(List<CompanyX> XPOLines217) {
        this.XPOLines217 = XPOLines217;
    }
}
