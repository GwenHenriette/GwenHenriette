package com0.A4.service;

import com0.A4.model.CompanyX;
import com0.A4.model.CompanyY;
import com0.A4.repository.CompanyXRepository;
import com0.A4.repository.CompanyYRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CompanyYService {

    private final CompanyYRepository companyYRepository;

    @Autowired
    public CompanyYService(CompanyYRepository companyYRepository) {
        this.companyYRepository = companyYRepository;
    }

    public List<CompanyY> getAllParts217(){
        return companyYRepository.findAll();
    }

    public List<CompanyY> getAllPurchaseOrders217(){
        List<CompanyY> purchaseorders = new ArrayList<>();
        companyYRepository.findAll().forEach(purchaseorders::add);
        return purchaseorders;
    }

    public void addpurchaseorders217(CompanyY pos217){
        companyYRepository.save(pos217);
    }

    public void updatePurchaseOrders217(int id, CompanyY pos217){
        companyYRepository.save(pos217);
    }

    public CompanyY createCompany217(CompanyY company){
        return companyYRepository.save(company);
    }

    public CompanyY updateCompany217(String companyId, CompanyY updatecompany){
        return companyYRepository.save(updatecompany);
    }

    public void deletecompany(String companyId){
        companyYRepository.deleteById(companyId);
    }


}
