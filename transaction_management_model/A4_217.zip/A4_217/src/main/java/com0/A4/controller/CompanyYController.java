package com0.A4.controller;

import com0.A4.model.CompanyY;
import com0.A4.service.CompanyYService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/CompanyY")
public class CompanyYController {

    private final CompanyYService companyYService;

    @Autowired
    public CompanyYController(CompanyYService companyYService) {
        this.companyYService = companyYService;
    }


    @GetMapping ("/getAllParts217")
    public List<CompanyY> getAllParts217(){
        return companyYService.getAllParts217();
    }

    @GetMapping("/getAllPurchaseOrders217")
    public List<CompanyY> getAllPurchaseOrders217(){
        return companyYService.getAllPurchaseOrders217();
    }


    @PostMapping
    public void addPurchaseOrders217(@RequestBody CompanyY companyYPO){
        companyYService.addpurchaseorders217(companyYPO);
    }


    @PutMapping("/updatepurchaseOrders/{id}")
    public void updatepurchaseOrders217(@PathVariable String id, @RequestBody CompanyY companyYPO){
        companyYService.updateCompany217(id, companyYPO);
    }

}
