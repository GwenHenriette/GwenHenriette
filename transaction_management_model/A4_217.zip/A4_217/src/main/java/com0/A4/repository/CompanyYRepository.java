package com0.A4.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com0.A4.model.CompanyY;
import java.util.Optional;

public interface CompanyYRepository extends MongoRepository<CompanyY, String> {
    @Override
    Optional<CompanyY> findById(String i);
}
