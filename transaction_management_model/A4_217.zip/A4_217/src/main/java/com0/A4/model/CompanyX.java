package com0.A4.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "CompanyX")
public class CompanyX {
    @Id
    private String id;
    private String Client217;
    private String User217;
    private String[] Parts217;
    private String[] POs217;
    private String[] POLines217;

    public CompanyX(String id, String client217, String user217, String[] parts217, String[] POs217, String[] POLines217) {
        this.id = id;
        Client217 = client217;
        User217 = user217;
        Parts217 = parts217;
        this.POs217 = POs217;
        this.POLines217 = POLines217;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClient217() {
        return Client217;
    }

    public void setClient217(String client217) {
        Client217 = client217;
    }

    public String getUser217() {
        return User217;
    }

    public void setUser217(String user217) {
        User217 = user217;
    }

    public String[] getParts217() {
        return Parts217;
    }

    public void setParts217(String[] parts217) {
        Parts217 = parts217;
    }

    public String[] getPOs217() {
        return POs217;
    }

    public void setPOs217(String[] POs217) {
        this.POs217 = POs217;
    }
}
