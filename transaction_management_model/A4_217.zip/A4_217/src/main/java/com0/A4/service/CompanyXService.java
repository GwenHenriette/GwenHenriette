package com0.A4.service;

import com0.A4.model.CompanyX;
import com0.A4.repository.CompanyXRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CompanyXService {

    private final CompanyXRepository companyXRepository;

    @Autowired
    public CompanyXService(CompanyXRepository companyXRepository) {
        this.companyXRepository = companyXRepository;
    }

    public List<CompanyX> getAllParts217(){
      return companyXRepository.findAll();
    }

    public List<CompanyX> getAllPurchaseOrders217(){
        List<CompanyX> purchaseorders = new ArrayList<>();
        companyXRepository.findAll().forEach(purchaseorders::add);
        return purchaseorders;
    }

    public void addpurchaseorders217(CompanyX pos217){
        companyXRepository.save(pos217);
    }

    public void updatePurchaseOrders217(int id, CompanyX pos217){
        companyXRepository.save(pos217);
    }

    public CompanyX createCompany217(CompanyX company){
        return companyXRepository.save(company);
    }

    public CompanyX updateCompany217(String companyId, CompanyX updatecompany){
        return companyXRepository.save(updatecompany);
    }

    public void deletecompany(String companyId){
        companyXRepository.deleteById(companyId);
    }


}
