package com0.A4.controller;

import com0.A4.model.CompanyX;
import com0.A4.model.CompanyY;
import com0.A4.service.CompanyXService;
import com0.A4.service.CompanyYService;
import com0.A4.service.CompanyZService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/CompanyZ")
public class CompanyZController {

    private final CompanyZService companyZService;
    private final CompanyYService companyYService;
    private final CompanyXService companyXService;

    @Autowired
    public CompanyZController(CompanyZService companyZService, CompanyYService companyYService, CompanyXService companyXService) {
        this.companyZService = companyZService;
        this.companyYService = companyYService;
        this.companyXService = companyXService;
    }


    @GetMapping ("/getAllParts217")
    public List<CompanyX> getAllXParts217(){
        return companyXService.getAllParts217();
    }

    @GetMapping("/getAllPurchaseOrders217")
    public List<CompanyX> getAllXPurchaseOrders217(){
        return companyXService.getAllPurchaseOrders217();
    }



    @PostMapping
    public void addXPurchaseOrders217(@RequestBody CompanyX companyXPO){
        companyXService.addpurchaseorders217(companyXPO);
    }


    @PutMapping("/updatepurchaseOrders/{id}")
    public void updateXpurchaseOrders217(@PathVariable String id, @RequestBody CompanyX companyXPO){
        companyXService.updateCompany217(id, companyXPO);
    }


}
