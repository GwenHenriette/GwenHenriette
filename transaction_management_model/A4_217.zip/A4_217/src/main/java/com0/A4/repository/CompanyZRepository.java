package com0.A4.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com0.A4.model.CompanyZ;
import java.util.Optional;

public interface CompanyZRepository extends MongoRepository<CompanyZ, String> {
    @Override
    Optional<CompanyZ> findById(String i);
}
