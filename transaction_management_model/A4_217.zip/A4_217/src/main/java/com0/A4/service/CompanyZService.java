package com0.A4.service;

import com0.A4.model.CompanyX;
import com0.A4.model.CompanyY;
import com0.A4.repository.CompanyZRepository;
import com0.A4.repository.CompanyYRepository;
import com0.A4.repository.CompanyXRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CompanyZService {

    private final CompanyXRepository companyXRepository;
    private final CompanyZRepository companyZRepository;
    private final CompanyYRepository companyYRepository;

    @Autowired
    public CompanyZService(CompanyXRepository companyXRepository, CompanyZRepository companyZRepository, CompanyYRepository companyYRepository) {
        this.companyXRepository = companyXRepository;
        this.companyZRepository = companyZRepository;
        this.companyYRepository = companyYRepository;
    }


    public List<CompanyX> getAllParts217(){
        return companyXRepository.findAll();
    }

    public List<CompanyX> getAllPOX217(){
        List<CompanyX> purchaseorders = new ArrayList<>();
        companyXRepository.findAll().forEach(purchaseorders::add);
        return purchaseorders;
    }
    public List<CompanyY> getAllPOY217(){
        List<CompanyY> purchaseorders = new ArrayList<>();
        companyYRepository.findAll().forEach(purchaseorders::add);
        return purchaseorders;
    }

    public void addPOX217(CompanyX pos217){
        companyXRepository.save(pos217);
    }

    public void addPOY217(CompanyY pos217){
        companyYRepository.save(pos217);
    }

    public void updatePOX217(int id, CompanyX pos217){
        companyXRepository.save(pos217);
    }
    public void updatePOY217(int id, CompanyY pos217){
        companyYRepository.save(pos217);
    }

    public CompanyX createCompanyX217(CompanyX company){
        return companyXRepository.save(company);
    }
    public CompanyY createCompanyY217(CompanyY company){
        return companyYRepository.save(company);
    }

    public CompanyX updateCompanyX217(String companyId, CompanyX updatecompany){
        return companyXRepository.save(updatecompany);
    }
    public CompanyY updateCompanyY217(String companyId, CompanyY updatecompany){
        return companyYRepository.save(updatecompany);
    }


    public void deletecompanyX(String companyId){
        companyXRepository.deleteById(companyId);
    }
    public void deletecompanyY(String companyId){
        companyYRepository.deleteById(companyId);
    }


}
