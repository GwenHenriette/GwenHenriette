package com0.A4.controller;

import com0.A4.model.CompanyX;
import com0.A4.service.CompanyXService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/CompanyX")
public class CompanyXController {

    private final CompanyXService companyXService;

    @Autowired
    public CompanyXController(CompanyXService companyXService) {
        this.companyXService = companyXService;
    }


    @GetMapping ("/getAllParts217")
    public List<CompanyX> getAllParts217(){
        return companyXService.getAllParts217();
    }

    @GetMapping("/getAllPurchaseOrders217")
    public List<CompanyX> getAllPurchaseOrders217(){
        return companyXService.getAllPurchaseOrders217();
    }


    @PostMapping
    public void addPurchaseOrders217(@RequestBody CompanyX companyXPO){
        companyXService.addpurchaseorders217(companyXPO);
    }


    @PutMapping("/updatepurchaseOrders/{id}")
    public void updatepurchaseOrders217(@PathVariable String id, @RequestBody CompanyX companyXPO){
        companyXService.updateCompany217(id, companyXPO);
    }

}
